const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = 3001;
app.use(cors());
app.use(bodyParser.json());

const db = new sqlite3.Database('./backend/database/biblioteca.db');

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nome TEXT NOT NULL, email TEXT NOT NULL)");
    db.run("CREATE TABLE IF NOT EXISTS livros (id INTEGER PRIMARY KEY, titulo TEXT NOT NULL, autor TEXT NOT NULL, genero TEXT NOT NULL, status TEXT DEFAULT 'quero ler', usuario_id INTEGER NOT NULL)");
});

app.get('/', (req, res) => res.send('Servidor Express rodando!'));

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
