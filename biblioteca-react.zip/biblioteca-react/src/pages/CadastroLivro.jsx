import { useState } from 'react';

const CadastroLivro = () => {
    const [titulo, setTitulo] = useState('');
    const [autor, setAutor] = useState('');
    const [genero, setGenero] = useState('');
    const [status, setStatus] = useState('quero ler');

    const handleSubmit = async (e) => {
        e.preventDefault();
        await fetch('http://localhost:3001/livros', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ titulo, autor, genero, status })
        });
        alert('Livro cadastrado com sucesso!');
    };

    return (
        <div>
            <h2>Cadastro de Livro</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" placeholder="Título" value={titulo} onChange={(e) => setTitulo(e.target.value)} required />
                <input type="text" placeholder="Autor" value={autor} onChange={(e) => setAutor(e.target.value)} required />
                <input type="text" placeholder="Gênero" value={genero} onChange={(e) => setGenero(e.target.value)} required />
                <select value={status} onChange={(e) => setStatus(e.target.value)}>
                    <option value="quero ler">Quero Ler</option>
                    <option value="lendo">Lendo</option>
                    <option value="lido">Lido</option>
                </select>
                <button type="submit">Cadastrar</button>
            </form>
        </div>
    );
};

export default CadastroLivro;
