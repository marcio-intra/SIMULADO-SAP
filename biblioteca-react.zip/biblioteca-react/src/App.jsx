import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CadastroUsuario from './pages/CadastroUsuario';
import CadastroLivro from './pages/CadastroLivro';
import Menu from './components/Menu';

function App() {
    return (
        <BrowserRouter>
            <Menu />
            <Routes>
                <Route path="/" element={<h1>Bem-vindo à Biblioteca Pessoal!</h1>} />
                <Route path="/cadastro-usuario" element={<CadastroUsuario />} />
                <Route path="/cadastro-livro" element={<CadastroLivro />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;
